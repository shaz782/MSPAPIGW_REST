/**
 * SubscriberServiceV1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xius.msp.billing.client.SubscriberManagementV1;

public interface SubscriberServiceV1 extends javax.xml.rpc.Service {
    public java.lang.String getSubscriberManagementPortV1Address();

    public com.xius.msp.billing.client.SubscriberManagementV1.SubscriberManagementPortTypeV1 getSubscriberManagementPortV1() throws javax.xml.rpc.ServiceException;

    public com.xius.msp.billing.client.SubscriberManagementV1.SubscriberManagementPortTypeV1 getSubscriberManagementPortV1(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
