/**
 * ReportService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xius.msp.billing.client.reportManagement;

public interface ReportService extends javax.xml.rpc.Service {
    public java.lang.String getReportManagementPortAddress();

    public com.xius.msp.billing.client.reportManagement.ReportManagementPortType getReportManagementPort() throws javax.xml.rpc.ServiceException;

    public com.xius.msp.billing.client.reportManagement.ReportManagementPortType getReportManagementPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
